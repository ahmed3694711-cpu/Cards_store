import { useState } from "react";
import { Gift, ShoppingCart, CreditCard, Sparkles, Shield, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Footer } from "@/components/Footer";

interface GiftCard {
  id: number;
  game: string;
  amount: number;
  price: number;
  image: string;
  color: string;
  popular?: boolean;
}

const giftCards: GiftCard[] = [
  { id: 1, game: "فري فاير", amount: 100, price: 85, image: "🔥", color: "from-orange-500 to-red-600", popular: true },
  { id: 2, game: "ببجي", amount: 325, price: 95, image: "🎯", color: "from-yellow-500 to-orange-600", popular: true },
  { id: 3, game: "فورتنايت", amount: 1000, price: 120, image: "⚡", color: "from-purple-500 to-indigo-600" },
  { id: 4, game: "كول أوف ديوتي", amount: 500, price: 110, image: "🎮", color: "from-slate-600 to-slate-800" },
  { id: 5, game: "روبلوكس", amount: 800, price: 90, image: "🧱", color: "from-red-500 to-pink-600" },
  { id: 6, game: "ماين كرافت", amount: 1000, price: 130, image: "⛏️", color: "from-green-500 to-emerald-700" },
];

export default function App() {
  const [cart, setCart] = useState<GiftCard[]>([]);
  const [email, setEmail] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("card");

  const addToCart = (card: GiftCard) => {
    setCart([...cart, card]);
  };

  const removeFromCart = (id: number) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-indigo-50/30" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-indigo-100 bg-white/80 backdrop-blur-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-200">
              <Gift className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">بطاقات<span className="text-indigo-600">نا</span></h1>
              <p className="text-xs text-slate-500">متجر بطاقات الهدايا</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-indigo-50 text-indigo-700 hover:bg-indigo-100">
              <Sparkles className="ml-1 h-3 w-3" />
              خصم 10% على أول عملية
            </Badge>
            <Button variant="outline" className="relative">
              <ShoppingCart className="ml-2 h-4 w-4" />
              السلة
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-indigo-600 text-xs text-white">
                  {cart.length}
                </span>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-l from-indigo-600 via-violet-600 to-purple-700 py-16">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 text-8xl">🎮</div>
          <div className="absolute bottom-10 left-10 text-8xl">💎</div>
          <div className="absolute top-20 left-1/4 text-6xl">⚡</div>
        </div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <Badge className="mb-4 bg-white/20 text-white hover:bg-white/30">
              <Zap className="ml-1 h-3 w-3" />
              توصيل فوري
            </Badge>
            <h2 className="mb-4 text-4xl font-bold text-white sm:text-5xl">
              بطاقات هدايا للألعاب
              <span className="block text-2xl text-indigo-200 sm:text-3xl">بأفضل الأسعار وأسرع توصيل</span>
            </h2>
            <p className="mb-8 text-lg text-indigo-100">
              اشحن رصيدك في ألعابك المفضلة خلال دقائق. آمن، سريع، وموثوق.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-white text-indigo-700 hover:bg-indigo-50">
                تسوق الآن
              </Button>
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                كيف يعمل؟
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-6 sm:grid-cols-3">
          {[
            { icon: Zap, title: "توصيل فوري", desc: "استلم الكود خلال دقائق" },
            { icon: Shield, title: "دفع آمن", desc: "تشفير كامل لبياناتك" },
            { icon: CreditCard, title: "طرق دفع متعددة", desc: "بطاقات، محافظ، تحويل" },
          ].map((feature, i) => (
            <Card key={i} className="border-indigo-100 bg-white/80 shadow-sm">
              <CardContent className="flex items-center gap-4 p-6">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
                  <feature.icon className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">{feature.title}</h3>
                  <p className="text-sm text-slate-500">{feature.desc}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Gift Cards Grid */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">البطاقات المتوفرة</h2>
            <p className="mt-2 text-slate-500">اختر لعبتك المفضلة واشحن رصيدك الآن</p>
          </div>
          <Badge className="bg-indigo-50 text-indigo-700">
            {giftCards.length} لعبة متاحة
          </Badge>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {giftCards.map((card) => (
            <Card key={card.id} className="group overflow-hidden border-indigo-100 transition-all hover:shadow-xl">
              <div className={`relative bg-gradient-to-br ${card.color} p-6`}>
                {card.popular && (
                  <Badge className="absolute top-4 right-4 bg-white/20 text-white">
                    الأكثر مبيعاً
                  </Badge>
                )}
                <div className="text-6xl">{card.image}</div>
                <h3 className="mt-4 text-xl font-bold text-white">{card.game}</h3>
                <p className="text-sm text-white/80">بطاقة هدايا</p>
              </div>
              <CardContent className="p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500">قيمة البطاقة</p>
                    <p className="text-2xl font-bold text-slate-900">{card.amount} نقطة</p>
                  </div>
                  <div className="text-left">
                    <p className="text-sm text-slate-500">السعر</p>
                    <p className="text-2xl font-bold text-indigo-600">{card.price} ر.س</p>
                  </div>
                </div>
                <Button 
                  className="w-full bg-indigo-600 hover:bg-indigo-700"
                  onClick={() => addToCart(card)}
                >
                  <ShoppingCart className="ml-2 h-4 w-4" />
                  أضف إلى السلة
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Cart Section */}
      {cart.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
          <Card className="border-indigo-100 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5 text-indigo-600" />
                سلة المشتريات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cart.map((item, index) => (
                  <div key={index} className="flex items-center justify-between rounded-xl bg-slate-50 p-4">
                    <div className="flex items-center gap-4">
                      <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${item.color} text-2xl`}>
                        {item.image}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{item.game}</p>
                        <p className="text-sm text-slate-500">{item.amount} نقطة</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <p className="font-bold text-indigo-600">{item.price} ر.س</p>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-red-500 hover:text-red-600"
                        onClick={() => removeFromCart(item.id)}
                      >
                        إزالة
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 border-t border-indigo-100 pt-6">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-lg font-bold text-slate-900">الإجمالي</span>
                  <span className="text-2xl font-bold text-indigo-600">{total} ر.س</span>
                </div>

                <div className="mb-4">
                  <Label htmlFor="email">البريد الإلكتروني لاستلام الكود</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="example@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div className="mb-6">
                  <Label>طريقة الدفع</Label>
                  <div className="mt-2 grid gap-3 sm:grid-cols-3">
                    {["card", "wallet", "bank"].map((method) => (
                      <button
                        key={method}
                        onClick={() => setPaymentMethod(method)}
                        className={`rounded-xl border-2 p-4 text-center transition-all ${
                          paymentMethod === method
                            ? "border-indigo-600 bg-indigo-50"
                            : "border-slate-200 hover:border-indigo-300"
                        }`}
                      >
                        <CreditCard className="mx-auto mb-2 h-6 w-6 text-indigo-600" />
                        <span className="text-sm font-bold text-slate-900">
                          {method === "card" ? "بطاقة ائتمانية" : method === "wallet" ? "محفظة إلكترونية" : "تحويل بنكي"}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <Button className="w-full bg-gradient-to-l from-indigo-600 to-violet-600 py-6 text-lg hover:from-indigo-700 hover:to-violet-700">
                  <Shield className="ml-2 h-5 w-5" />
                  ادفع الآن بأمان
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      <Footer />
    </div>
  );
}